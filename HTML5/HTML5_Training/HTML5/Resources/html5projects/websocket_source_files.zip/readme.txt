To run the server, in the command line type:
php -q htdocs\socket\server\startDaemon.php


Access the client from your browser like this (change the path depending on where your files are stored):
http://localhost/socket/client/client.php 